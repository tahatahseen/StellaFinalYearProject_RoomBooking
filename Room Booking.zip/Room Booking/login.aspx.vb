﻿Imports System.Data
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String
   
    Protected Sub Btnlogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btnlogin.Click
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from LoginDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        Dim LoginID As String = Tbxloginid.Text
        Dim pwd As String = Tbxpwd.Text
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If LoginID = ds.Tables(0).Rows(i).Item(0) Then
                If pwd = ds.Tables(0).Rows(i).Item(1) Then
                    If LoginID = "admin" And pwd = "admin" Then
                        Session("LoginID") = Tbxloginid.Text.ToString
                        Response.Redirect("Frontpage.aspx")
                    Else
                        Session("LoginID") = Tbxloginid.Text.ToString
                        Response.Redirect("UsersFrontPage.aspx")
                    End If
                End If
            End If
        Next
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If LoginID <> ds.Tables(0).Rows(i).Item(0) Then
                If pwd <> ds.Tables(0).Rows(i).Item(1) Then
                    MsgBox("Your LoginID Or Password Is Incorrect")
                    Tbxloginid.Text = ""
                    Tbxpwd.Text = ""
                    Tbxloginid.Focus()
                    Exit For
                End If
            End If
        Next

    End Sub

    
    
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Tbxloginid.Focus()
    End Sub
End Class
