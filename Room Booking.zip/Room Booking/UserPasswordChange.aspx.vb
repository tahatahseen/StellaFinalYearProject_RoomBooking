﻿Imports System.Data
Partial Class PasswordChange
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String
    Dim SnLoginID As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SnLoginID = Session("LoginID").ToString
        tbxloginid.Text = SnLoginID
    End Sub

    Protected Sub btnupdatepwd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnupdatepwd.Click
        Dim currentpwd As String
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from LoginDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        cb = New OleDb.OleDbCommandBuilder(ad)
        If tbxnewpwd.Text <> tbxconfirmpwd.Text Then
            MsgBox("Sorry, The new password and confirm password field should be the same")
            tbxconfirmpwd.Text = ""
            tbxnewpwd.Text = ""
        Else
            For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
                If tbxloginid.Text = ds.Tables(0).Rows(i).Item(0) Then
                    currentpwd = ds.Tables(0).Rows(i).Item(1)
                    If currentpwd = tbxcurrentpwd.Text Then
                        ds.Tables(0).Rows(i).Item(1) = tbxconfirmpwd.Text
                        MsgBox("Updated")
                    Else
                        MsgBox("Please enter the  correct current password")
                        tbxcurrentpwd.Text = ""
                        tbxconfirmpwd.Focus()
                    End If
                End If
            Next
            ad.Update(ds)
            Response.Redirect("UsersFrontPage.aspx")
        End If
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub
End Class
