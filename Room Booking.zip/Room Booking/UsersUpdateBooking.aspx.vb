﻿Imports System.Data
Partial Class UsersUpdateBooking
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ad1 As OleDb.OleDbDataAdapter
    Dim ad2 As OleDb.OleDbDataAdapter
    Dim ad3 As OleDb.OleDbDataAdapter
    Dim ad4 As OleDb.OleDbDataAdapter
    Dim ad5 As OleDb.OleDbDataAdapter
    Dim ad6 As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim ds1 As New Data.DataSet
    Dim ds2 As New Data.DataSet
    Dim ds3 As New Data.DataSet
    Dim ds4 As New Data.DataSet
    Dim ds5 As New Data.DataSet
    Dim ds6 As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str1, str2, str, conn, str3, str4, str5 As String
    Dim SnLoginID As String
    Dim BkngID, waitingID As Integer
    Dim projec As String
    Dim Rowno, Rowno1, Rowno2, Rownos, oldbkid, oldwtid, var As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SnLoginID = Session("LoginID").ToString
        tbxloginid.Text = SnLoginID
        tbxtodaydate.Text = Date.Today
        Dim flag = 0
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str1 = "select * from BookingDetails"
        ad1 = New OleDb.OleDbDataAdapter(str1, conn)
        ad1.Fill(ds1)
        cb = New OleDb.OleDbCommandBuilder(ad1)
        For i As Integer = 0 To ds1.Tables(0).Rows.Count - 1
            If tbxloginid.Text = ds1.Tables(0).Rows(i).Item(0) And tbxtodaydate.Text <= ds1.Tables(0).Rows(i).Item(5) Then
                flag = 1
            End If
        Next
        If flag = 0 Then
            lblavail.Visible = True
            lblbkgid.Visible = False
            dropdownbookingid.Visible = False
            Button1.Visible = False
        End If
    End Sub

    Protected Sub btnvalidate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnvalidate.Click
        If tbxmike.Text > textmike.Text Or tbxchair.Text > textchair.Text Then
            MsgBox("Please enter a valid number")
            btnvalidate.Visible = True
        Else
            Btnconfirm.Visible = True
            btnvalidate.Visible = False
        End If
        If radiono.Checked = True Then
            projec = "No"
        ElseIf radioyes.Checked = True Then
            projec = "Yes"
        Else
            MsgBox("please choose an option")
        End If
        
    End Sub

    Protected Sub Btnconfirm_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btnconfirm.Click
        If radiono.Checked = True Then
            projec = "No"
        ElseIf radioyes.Checked = True Then
            projec = "Yes"
        End If
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str1 = "select * from BookingDetails"
        ad1 = New OleDb.OleDbDataAdapter(str1, conn)
        ad1.Fill(ds1)
        cb = New OleDb.OleDbCommandBuilder(ad1)
        For i As Integer = 0 To ds1.Tables(0).Rows.Count - 1
            If dropdownbookingid.SelectedItem.Text = ds1.Tables(0).Rows(i).Item(1) Then
                ds1.Tables(0).Rows(i).Item(4) = TbxDescription.Text
                ds1.Tables(0).Rows(i).Item(8) = tbxchair.Text
                ds1.Tables(0).Rows(i).Item(9) = tbxmike.Text
                ds1.Tables(0).Rows(i).Item(10) = projec
            End If
        Next
        ad1.Update(ds1)
        MsgBox("Updation Successful")
        If TbxDeptName.Text = "Adminstrator" Then
            Response.Redirect("Frontpage.aspx")
        Else
            Response.Redirect("UsersFrontPage.aspx")
        End If

    End Sub


    Protected Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        lblvenue.Visible = True
        tbxvenue.Visible = True
        tbxvenue.Enabled = False
        lbldeptname.Visible = True
        TbxDeptName.Visible = True
        TbxDeptName.Enabled = False
        lbldesc.Visible = True
        TbxDescription.Visible = True
        lbldate.Visible = True
        TbxDate.Visible = True
        TbxDate.Enabled = False
        lblstarttime.Visible = True
        TbxStrtTime.Visible = True
        TbxStrtTime.Enabled = False
        lblendtime.Visible = True
        TbxEndTime.Visible = True
        TbxEndTime.Enabled = False
        Lblmikeavail.Visible = True
        Lblmikemax.Visible = True
        lblmike.Visible = True
        tbxmike.Visible = True
        LabelChair.Visible = True
        Lblchairavail.Visible = True
        tbxchair.Visible = True
        Lblchairmax.Visible = True
        LabelProjector.Visible = True
        radiono.Visible = True
        radioyes.Visible = True
        btnvalidate.Visible = True
        Dim bkid As Integer = dropdownbookingid.SelectedItem.Text
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from BookingDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If bkid = ds.Tables(0).Rows(i).Item(1) Then
                tbxvenue.Text = ds.Tables(0).Rows(i).Item(2)
                TbxDeptName.Text = ds.Tables(0).Rows(i).Item(3)
                TbxDescription.Text = ds.Tables(0).Rows(i).Item(4)
                TbxDate.Text = ds.Tables(0).Rows(i).Item(5)
                TbxStrtTime.Text = ds.Tables(0).Rows(i).Item(6)
                TbxEndTime.Text = ds.Tables(0).Rows(i).Item(7)
                tbxmike.Text = ds.Tables(0).Rows(i).Item(9).ToString
                tbxchair.Text = ds.Tables(0).Rows(i).Item(8).ToString
            End If
        Next
        str2 = "select * from ResourceDetails"
        ad3 = New OleDb.OleDbDataAdapter(str2, conn)
        ad3.Fill(ds3)
        For j As Integer = 0 To ds3.Tables(0).Rows.Count - 1
            If tbxvenue.Text = ds3.Tables(0).Rows(j).Item(0) Then
                textchair.Text = ds3.Tables(0).Rows(j).Item(1)
                textmike.Text = ds3.Tables(0).Rows(j).Item(2)
                textprojector.Text = ds3.Tables(0).Rows(j).Item(3)
                Lblchairmax.Text = ds3.Tables(0).Rows(j).Item(1)
                Lblmikemax.Text = ds3.Tables(0).Rows(j).Item(2)
            End If
        Next
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub
End Class

