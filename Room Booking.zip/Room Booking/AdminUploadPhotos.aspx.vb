﻿Imports System.Data
Partial Class AdminUploadPhotos
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String
    Protected Sub Btnupload_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btnupload.Click
        Dim SNo, SNos, oldSNo, NewSNo As Integer
        Dim filePath = "Room/"
        Dim filename = FileUpload1.FileName.ToString()
        FileUpload1.SaveAs(Server.MapPath(filePath) + filename)
        Image3.ImageUrl = filePath + filename

        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from RoomPictures"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        cb = New OleDb.OleDbCommandBuilder(ad)
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            SNo = ds.Tables(0).Rows.Count
            If SNo = 0 Then
                NewSNo = 1
            Else
                SNos = ds.Tables(0).Rows.Count - 1
                oldSNo = ds.Tables(0).Rows(SNos).Item(0)
                NewSNo = oldSNo + 1
            End If
        Next
        Dim items As Data.DataRow
        items = ds.Tables(0).NewRow
        items(0) = SNo
        items(1) = Image3.ImageUrl.ToString
        items(2) = DropDownList1.SelectedItem.Text
        ds.Tables(0).Rows.Add(items)
        ad.Update(ds)
        MsgBox("Uploaded Successfully")
        'Response.Redirect("Frontpage.aspx")
    End Sub
End Class
