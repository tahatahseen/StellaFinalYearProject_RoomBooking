﻿Imports System.Data
Partial Class UsersPage
    Inherits System.Web.UI.Page
    Dim ad, ad1, ad2, ad3, ad4 As OleDb.OleDbDataAdapter
    Dim ds, ds1, ds2, ds3, ds4 As New Data.DataSet
    Dim cb, cb1, cb2, cb4 As OleDb.OleDbCommandBuilder
    Dim str, str1, str2, str3, str4, conn As String
    Dim SnLoginID As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SnLoginID = Session("LoginID").ToString
        txtlogin.Text = SnLoginID
        Dim todaydate As String = Date.Today
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from CancelDetail"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)

        str3 = "select * from NotifyDeletedRoom"
        ad3 = New OleDb.OleDbDataAdapter(str3, conn)
        ad3.Fill(ds3)
        If ds3.Tables(0).Rows.Count = 0 Then
            hyperroom.Visible = False
        End If
        For j As Integer = 0 To ds3.Tables(0).Rows.Count - 1
            If txtlogin.Text = ds3.Tables(0).Rows(j).Item(1) And todaydate <= ds3.Tables(0).Rows(j).Item(6) Then
                hyperroom.Visible = True
            End If
        Next

        If ds.Tables(0).Rows.Count = 0 Then
            LabelNoNotify.Visible = True
        Else
            For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
                If txtlogin.Text = ds.Tables(0).Rows(i).Item(1) Then
                    HyperLinkyes.Visible = True
                    Exit For
                Else
                    LabelNoNotify.Visible = True
                End If
            Next

        End If
        str4 = "select * from RoomPictures"
        ad4 = New OleDb.OleDbDataAdapter(str4, conn)
        ad4.Fill(ds4)
        cb4 = New OleDb.OleDbCommandBuilder(ad4)
        DataList1.DataSource = ds4
        DataList1.DataBind()
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub

   
End Class
