﻿Imports System.Data
Partial Class NotificationPage
    Inherits System.Web.UI.Page
    Dim ad, ad1, ad2 As OleDb.OleDbDataAdapter
    Dim ds, ds1, ds2 As New Data.DataSet
    Dim cb, cb1 As OleDb.OleDbCommandBuilder
    Dim str, str1, str2, conn As String
    Dim SnLoginID As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SnLoginID = Session("LoginID").ToString
        tbxloginidinvisible.Text = SnLoginID
        tbxtodaydate.Text = Date.Today
    End Sub

    Protected Sub btndecline_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btndecline.Click
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str1 = "select * from CancelDetail"
        ad1 = New OleDb.OleDbDataAdapter(str1, conn)
        ad1.Fill(ds1)
        cb = New OleDb.OleDbCommandBuilder(ad1)
        For i As Integer = 0 To ds1.Tables(0).Rows.Count - 1
            If dropdownbookingid.Items(0).Text = ds1.Tables(0).Rows(i).Item(2) Then
                ds1.Tables(0).Rows(i).Delete()
                Exit For
            End If
        Next
        ad1.Update(ds1)
        Response.Redirect("UsersFrontPage.aspx")
    End Sub

    Protected Sub btnaccept_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnaccept.Click
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str2 = "select * from CancelDetail"
        ad2 = New OleDb.OleDbDataAdapter(str2, conn)
        ad2.Fill(ds2)
        cb1 = New OleDb.OleDbCommandBuilder(ad2)
        For i As Integer = 0 To ds2.Tables(0).Rows.Count - 1
            If dropdownbookingid.SelectedItem.Text = ds2.Tables(0).Rows(i).Item(2) Then
                Session("Venue") = tbxvenue.Text.ToString
                Session("Date") = tbxdate.Text.ToString
                Session("StartTime") = tbxstart.Text.ToString
                Session("EndTime") = tbxend.Text.ToString
                Session("BookingID") = dropdownbookingid.SelectedItem.Text
                'ds2.Tables(0).Rows(i).Delete()
            End If
        Next
        'ad2.Update(ds2)
        Response.Redirect("NewBooking.aspx")
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub

    Protected Sub btnfetch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnfetch.Click
        LabelLoginID.Visible = True
        tbxlogin.Visible = True
        LabelVenue.Visible = True
        tbxvenue.Visible = True
        LabelDate.Visible = True
        tbxdate.Visible = True
        Labelstart.Visible = True
        tbxstart.Visible = True
        LabelEnd.Visible = True
        tbxend.Visible = True
        btnaccept.Visible = True
        btndecline.Visible =True
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from CancelDetail"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If dropdownbookingid.SelectedItem.Text = ds.Tables(0).Rows(i).Item(2) Then
                tbxlogin.Text = ds.Tables(0).Rows(i).Item(1).ToString
                tbxvenue.Text = ds.Tables(0).Rows(i).Item(3).ToString
                tbxdate.Text = ds.Tables(0).Rows(i).Item(4).ToString
                tbxstart.Text = ds.Tables(0).Rows(i).Item(5).ToString
                tbxend.Text = ds.Tables(0).Rows(i).Item(6).ToString
            End If
        Next
    End Sub
End Class
