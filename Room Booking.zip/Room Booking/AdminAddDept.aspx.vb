﻿Imports System.Data
Partial Class AdminAddDept
    Inherits System.Web.UI.Page
    Dim ad1 As OleDb.OleDbDataAdapter
    Dim ds1 As New Data.DataSet
    Dim cb1 As OleDb.OleDbCommandBuilder
    Dim str1, conn As String
    Protected Sub btnadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Dim Rowno, Rownos, oldbkid, BkngID As Integer
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str1 = "select * from DepartmentNames"
        ad1 = New OleDb.OleDbDataAdapter(str1, conn)
        ad1.Fill(ds1)
        Rowno = ds1.Tables(0).Rows.Count
        If Rowno = 0 Then
            BkngID = 1
        Else
            Rownos = ds1.Tables(0).Rows.Count - 1
            oldbkid = ds1.Tables(0).Rows(Rownos).Item(0)
            BkngID = oldbkid + 1
        End If
        cb1 = New OleDb.OleDbCommandBuilder(ad1)
        If Rowno = 0 Then
            Dim items As Data.DataRow
            items = ds1.Tables(0).NewRow
            items(0) = BkngID
            items(1) = tbxdeptname.Text
            ds1.Tables(0).Rows.Add(items)
            ad1.Update(ds1)
            MsgBox("Added Successfully")
            Response.Redirect("Frontpage.aspx")
        Else
            For i As Integer = 0 To ds1.Tables(0).Rows.Count - 1
                If tbxdeptname.Text = ds1.Tables(0).Rows(i).Item(1) Then
                    MsgBox("This department already exists")
                    Exit For
                Else
                    Dim items As Data.DataRow
                    items = ds1.Tables(0).NewRow
                    items(0) = BkngID
                    items(1) = tbxdeptname.Text
                    ds1.Tables(0).Rows.Add(items)
                    ad1.Update(ds1)
                    MsgBox("Added Successfully")
                    Response.Redirect("Frontpage.aspx")
                End If
            Next
        End If
    End Sub
End Class
