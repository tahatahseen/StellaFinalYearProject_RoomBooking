﻿Imports System.Data
Partial Class Booking
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ad1 As OleDb.OleDbDataAdapter
    Dim ad2 As OleDb.OleDbDataAdapter
    Dim ad3 As OleDb.OleDbDataAdapter
    Dim ad4 As OleDb.OleDbDataAdapter
    Dim ad5 As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim ds1 As New Data.DataSet
    Dim ds2 As New Data.DataSet
    Dim ds3 As New Data.DataSet
    Dim ds4 As New Data.DataSet
    Dim ds5 As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str1, str2, str, conn, str3, str4 As String
    Dim SnLoginID As String
    Dim BkngID, waitingID As Integer
    Dim projector As String = ""
    Dim Rowno, Rowno1, Rowno2, Rownos, oldbkid, oldwtid, BookingID As Integer
    Private MinDate As Date = Date.MinValue
    Private MaxDate As Date = Date.MaxValue

    Protected Sub btncal_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btncal.Click
        Caldate.Visible = True
    End Sub
    Protected Sub Caldate_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Caldate.SelectionChanged
        TbxDate.Text = Caldate.SelectedDate
        If TbxDate.Text >= RangeValidatordate.MinimumValue Or TbxDate.Text <= RangeValidatordate.MaximumValue Then
            Caldate.Visible = False
            Label1.Visible = False
        Else
            Label1.Visible = True
            TbxDate.Text = ""
            TbxDate.Focus()
        End If
    End Sub
    Protected Sub Caldate_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles Caldate.DayRender
        If (e.Day.Date.DayOfWeek = DayOfWeek.Sunday) Then

            'e.Cell.ApplyStyle(new Style { BackColor = System.Drawing.Color.Gray })
            e.Day.IsSelectable = False
        End If
        If e.Day.Date <= MinDate OrElse e.Day.Date >= MaxDate Then
            e.Day.IsSelectable = False

        End If
    End Sub
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        RangeValidatordate.MinimumValue = DateTime.Now.Date.ToString("MM/dd/yy")
        RangeValidatordate.MaximumValue = Date.Today.AddMonths(1)

        MinDate = Date.Today
        MaxDate = MinDate.AddMonths(1)

        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from LoginDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        SnLoginID = Session("LoginID").ToString
        tbxloginid.Text = SnLoginID
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If tbxloginid.Text = ds.Tables(0).Rows(i).Item(0) Then
                TbxDeptName.Text = ds.Tables(0).Rows(i).Item(2).ToString
            End If
        Next
        str1 = "select * from BookingDetails"
        ad1 = New OleDb.OleDbDataAdapter(str1, conn)
        ad1.Fill(ds1)
        Rowno = ds1.Tables(0).Rows.Count
        If Rowno = 0 Then
            BkngID = 1
        Else
            Rownos = ds1.Tables(0).Rows.Count - 1
            oldbkid = ds1.Tables(0).Rows(Rownos).Item(1)
            BkngID = oldbkid + 1
        End If
        TbxBkId.Text = BkngID
    End Sub

    Protected Sub Btnchkavil_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btnchkavil.Click

        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str1 = "select * from BookingDetails"
        ad2 = New OleDb.OleDbDataAdapter(str1, conn)
        ad2.Fill(ds2)
        Dim Venue As String = Drpvenue.SelectedItem.Text
        Dim BookingDate As Date = TbxDate.Text
        Dim StrtTime As Double = TbxStrtTime.Text
        Dim EdTime As Double = TbxEndTime.Text
        Dim i As Integer
        If EdTime < StrtTime Then
            MsgBox("End Time Should be greater than start time")
            TbxEndTime.Text = ""
            TbxEndTime.Focus()

            LabelAvailable.Visible = False
            LabelMike.Visible = False
            tbxmike.Visible = False
            LabelChair.Visible = False
            tbxchair.Visible = False
            LabelProjector.Visible = False
            radioyes.Visible = False
            radiono.Visible = False
            Drpvenue.Enabled = True
            btncal.Visible = True
            TbxEndTime.Enabled = True
            TbxStrtTime.Enabled = True
            Btnchkavil.Visible = True
            TbxBkId.Enabled = True
            TbxDeptName.Enabled = True
            TbxDescription.Enabled = True
            tbxloginid.Enabled = True
            LabelAvailable.Visible = False
            LabelMike.Visible = False
            tbxmike.Visible = False
            LabelChair.Visible = False
            tbxchair.Visible = False
            LabelProjector.Visible = False
            radioyes.Visible = False
            radiono.Visible = False
            Btnconfirm.Visible = False
            Lblmikeavail.Visible = False
            Lblchairavail.Visible = False
            Lblmikemax.Visible = False
            Lblchairmax.Visible = False

        ElseIf ds2.Tables(0).Rows.Count = 0 Then
            LabelAvailable.Visible = True
            LabelMike.Visible = True
            tbxmike.Visible = True
            LabelChair.Visible = True
            tbxchair.Visible = True
            LabelProjector.Visible = True
            radioyes.Visible = True
            radiono.Visible = True
            Drpvenue.Enabled = False
            btncal.Visible = False
            TbxEndTime.Enabled = False
            TbxStrtTime.Enabled = False
            Btnchkavil.Visible = False
            TbxBkId.Enabled = False
            TbxDeptName.Enabled = False
            TbxDescription.Enabled = False
            tbxloginid.Enabled = False
            LabelAvailable.Visible = True
            LabelMike.Visible = True
            tbxmike.Visible = True
            LabelChair.Visible = True
            tbxchair.Visible = True
            LabelProjector.Visible = True
            radioyes.Visible = True
            radiono.Visible = True
            Btnconfirm.Visible = True
            str2 = "select * from ResourceDetails"
            ad3 = New OleDb.OleDbDataAdapter(str2, conn)
            ad3.Fill(ds3)
            For j As Integer = 0 To ds3.Tables(0).Rows.Count - 1
                If Venue = ds3.Tables(0).Rows(j).Item(0) Then
                    textchair.Text = ds3.Tables(0).Rows(j).Item(1)
                    textmike.Text = ds3.Tables(0).Rows(j).Item(2)
                    textprojector.Text = ds3.Tables(0).Rows(j).Item(3)
                    Lblchairmax.Text = ds3.Tables(0).Rows(j).Item(1)
                    Lblmikemax.Text = ds3.Tables(0).Rows(j).Item(2)
                End If
            Next
            Lblmikeavail.Visible = True
            Lblchairavail.Visible = True
            Lblmikemax.Visible = True
            Lblchairmax.Visible = True

        Else
            If ds2.Tables(0).Rows.Count > 0 Then

                For i = 0 To ds2.Tables(0).Rows.Count - 1
                    If TbxDeptName.Text = ds2.Tables(0).Rows(i).Item(3) And Venue = ds2.Tables(0).Rows(i).Item(2) And BookingDate = ds2.Tables(0).Rows(i).Item(5) And StrtTime <= ds2.Tables(0).Rows(i).Item(7) And EdTime <= ds2.Tables(0).Rows(i).Item(7) Then
                        MsgBox("Already booked by the same department")
                        If TbxDeptName.Text = "Adminstrator" Then
                            Response.Redirect("Frontpage.aspx")
                        Else
                            Response.Redirect("UsersFrontPage.aspx")
                        End If
                    ElseIf Venue = ds2.Tables(0).Rows(i).Item(2) And BookingDate = ds2.Tables(0).Rows(i).Item(5) And (StrtTime <= ds2.Tables(0).Rows(i).Item(7) Or EdTime <= ds2.Tables(0).Rows(i).Item(7)) Then
                        Btnchkavil.Visible = False
                        LabelNotAvailable.Visible = True
                        Btnwaitinglist.Visible = True
                        LabelAvailable.Visible = False
                        LabelMike.Visible = False
                        tbxmike.Visible = False
                        LabelChair.Visible = False
                        tbxchair.Visible = False
                        LabelProjector.Visible = False
                        radioyes.Visible = False
                        radiono.Visible = False
                        Btnconfirm.Visible = False
                        Lblmikeavail.Visible = False
                        Lblchairavail.Visible = False
                        Lblmikemax.Visible = False
                        Lblchairmax.Visible = False
                        Exit For
                    Else
                        Drpvenue.Enabled = False
                        btncal.Visible = False
                        TbxEndTime.Enabled = False
                        TbxStrtTime.Enabled = False
                        Btnchkavil.Visible = False
                        TbxBkId.Enabled = False
                        TbxDeptName.Enabled = False
                        TbxDescription.Enabled = False
                        tbxloginid.Enabled = False
                        LabelAvailable.Visible = True
                        LabelMike.Visible = True
                        tbxmike.Visible = True
                        LabelChair.Visible = True
                        tbxchair.Visible = True
                        LabelProjector.Visible = True
                        radioyes.Visible = True
                        radiono.Visible = True
                        Btnconfirm.Visible = True
                        str2 = "select * from ResourceDetails"
                        ad3 = New OleDb.OleDbDataAdapter(str2, conn)
                        ad3.Fill(ds3)
                        For j As Integer = 0 To ds3.Tables(0).Rows.Count - 1
                            If Venue = ds3.Tables(0).Rows(j).Item(0) Then
                                textchair.Text = ds3.Tables(0).Rows(j).Item(1)
                                textmike.Text = ds3.Tables(0).Rows(j).Item(2)
                                textprojector.Text = ds3.Tables(0).Rows(j).Item(3)
                                Lblchairmax.Text = ds3.Tables(0).Rows(j).Item(1)
                                Lblmikemax.Text = ds3.Tables(0).Rows(j).Item(2)
                            End If
                        Next
                        Lblmikeavail.Visible = True
                        Lblchairavail.Visible = True
                        Lblmikemax.Visible = True
                        Lblchairmax.Visible = True
                    End If
                Next

            End If
        End If
    End Sub
    Protected Sub BtnBook_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnBook.Click

        If radiono.Checked = True Then
            projector = "No"
        ElseIf radioyes.Checked = True Then
            projector = "Yes"
        Else
            MsgBox("please choose an option")

        End If
    End Sub

    Protected Sub Btnconfirm_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btnconfirm.Click
        If tbxmike.Text <= textmike.Text And tbxchair.Text <= textchair.Text Then
            BtnBook.Visible = True
            Btnconfirm.Visible = False
        Else
            Btnconfirm.Visible = True
            tbxmike.Enabled = True
            tbxmike.Enabled = True
        End If

        If radiono.Checked = True Then
            projector = "No"
            '    tbxchair.Enabled = False
            '    tbxmike.Enabled = False
        ElseIf radioyes.Checked = True Then
            projector = "Yes"
            'tbxchair.Enabled = False
            'tbxmike.Enabled = False
        Else
            MsgBox("please choose an option")
            Btnconfirm.Visible = True
            BtnBook.Visible = False

        End If
    End Sub
    Protected Sub OnConfirm(ByVal sender As Object, ByVal e As EventArgs) Handles BtnBook.Click

        If radiono.Checked = True Then
            projector = "No"
        ElseIf radioyes.Checked = True Then
            projector = "Yes"
        End If

        Dim confirmValue As String = Request.Form("confirm_value")

        If confirmValue = "Yes" Then

            conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
            str1 = "select * from BookingDetails"
            ad1 = New OleDb.OleDbDataAdapter(str1, conn)
            ad1.Fill(ds1)
            cb = New OleDb.OleDbCommandBuilder(ad1)
            Dim items As Data.DataRow
            items = ds1.Tables(0).NewRow
            items(0) = tbxloginid.Text
            items(1) = TbxBkId.Text
            items(2) = Drpvenue.SelectedItem.Text
            items(3) = TbxDeptName.Text
            items(4) = TbxDescription.Text
            items(5) = TbxDate.Text
            items(6) = TbxStrtTime.Text
            items(7) = TbxEndTime.Text
            items(8) = tbxchair.Text
            items(9) = tbxmike.Text
            items(10) = projector
            ds1.Tables(0).Rows.Add(items)
            ad1.Update(ds1)
            MsgBox("Booking Successful")
            If TbxDeptName.Text = "Adminstrator" Then
                Response.Redirect("Frontpage.aspx")
            Else
                Response.Redirect("UsersFrontPage.aspx")
            End If


        Else
            Response.Redirect("Booking1.aspx")


        End If

    End Sub
    Protected Sub Onwaiting(ByVal sender As Object, ByVal e As EventArgs) Handles Btnwaitinglist.Click

        Dim confirmValue As String = Request.Form("confirm_value")

        If confirmValue = "Yes" Then

            conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"

            str4 = "select * from BookingDetails"
            ad5 = New OleDb.OleDbDataAdapter(str4, conn)
            ad5.Fill(ds5)

            Dim Venue As String = Drpvenue.SelectedItem.Text
            Dim BookingDate As Date = TbxDate.Text
            Dim StrtTime As Double = TbxStrtTime.Text
            Dim EdTime As Double = TbxEndTime.Text
            Dim flag = 0

            For i = 0 To ds5.Tables(0).Rows.Count - 1
                'MsgBox("Hey")
                If ((Venue = ds5.Tables(0).Rows(i).Item(2)) And (BookingDate = ds5.Tables(0).Rows(i).Item(5)) And ((StrtTime <= ds5.Tables(0).Rows(i).Item(7)) Or (EdTime <= ds5.Tables(0).Rows(i).Item(7)))) Then
                    BookingID = ds5.Tables(0).Rows(i).Item(1)
                    'MsgBox(BookingID)
                End If
            Next

            str3 = "select * from WaitingDetails"
            ad4 = New OleDb.OleDbDataAdapter(str3, conn)
            ad4.Fill(ds4)
            cb = New OleDb.OleDbCommandBuilder(ad4)

            Rowno1 = ds4.Tables(0).Rows.Count
            If Rowno1 = 0 Then
                waitingID = 1
            Else
                Rowno2 = ds4.Tables(0).Rows.Count - 1
                oldwtid = ds4.Tables(0).Rows(Rowno2).Item(0)
                waitingID = oldwtid + 1
            End If

            If ds4.Tables(0).Rows.Count = 0 Then
                Dim items As Data.DataRow
                items = ds4.Tables(0).NewRow
                items(0) = waitingID
                items(1) = 1
                items(2) = SnLoginID
                items(3) = BookingID
                items(4) = Venue
                items(5) = BookingDate
                items(6) = StrtTime
                items(7) = EdTime
                ds4.Tables(0).Rows.Add(items)
                ad4.Update(ds4)
                MsgBox("Succesfully entered into the waiting list")
                If TbxDeptName.Text = "Adminstrator" Then
                    Response.Redirect("Frontpage.aspx")
                Else
                    Response.Redirect("UsersFrontPage.aspx")
                End If
            Else
                If ds4.Tables(0).Rows.Count > 0 Then
                    For j As Integer = 0 To ds4.Tables(0).Rows.Count - 1
                        If BookingID = ds4.Tables(0).Rows(j).Item(3) Then
                            flag = 0
                            MsgBox("Sorry,The waiting list is full")
                            If TbxDeptName.Text = "Adminstrator" Then
                                Response.Redirect("Frontpage.aspx")
                            Else
                                Response.Redirect("UsersFrontPage.aspx")
                            End If
                            Exit For
                        Else
                            flag = 1
                        End If
                    Next
                End If
            End If

            If flag = 1 Then
                Dim items As Data.DataRow
                items = ds4.Tables(0).NewRow
                items(0) = waitingID
                items(1) = 1
                items(2) = SnLoginID
                items(3) = BookingID
                items(4) = Venue
                items(5) = BookingDate
                items(6) = StrtTime
                items(7) = EdTime
                ds4.Tables(0).Rows.Add(items)
                ad4.Update(ds4)
                MsgBox("Succesfully entered into the waiting list")
                If TbxDeptName.Text = "Adminstrator" Then
                    Response.Redirect("Frontpage.aspx")
                Else
                    Response.Redirect("UsersFrontPage.aspx")
                End If
            End If

            Response.Redirect("Booking1.aspx")
        End If
    End Sub

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        If TbxDeptName.Text = "Adminstrator" Then
            Response.Redirect("Frontpage.aspx")
        Else
            Response.Redirect("UsersFrontPage.aspx")
        End If
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub

    
   
End Class
