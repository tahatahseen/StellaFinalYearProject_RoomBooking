﻿Imports System.Data
Partial Class AdminViewBooking
    Inherits System.Web.UI.Page
    Dim ad1 As OleDb.OleDbDataAdapter
    Dim ds1 As New Data.DataSet
    Dim cb1 As OleDb.OleDbCommandBuilder
    Dim str1, conn As String
    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str1 = "select * from BookingDetails"
        ad1 = New OleDb.OleDbDataAdapter(str1, conn)
        ad1.Fill(ds1)
        cb1 = New OleDb.OleDbCommandBuilder(ad1)
        If ds1.Tables(0).Rows.Count = 0 Then
            Lblnotavail.Visible = True
            GridView1.Visible = False
        End If
    End Sub

   
    Protected Sub Btnfilter_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btnfilter.Click
        Response.Redirect("AdminFilterPage.aspx")
    End Sub

    Protected Sub Btnfilteroom_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btnfilteroom.Click
        Response.Redirect("AdminFilterByRoom.aspx")
    End Sub
End Class
