﻿Imports System.Data
Partial Class AdminDeleteRooms
    Inherits System.Web.UI.Page
    Dim ad, ad1, ad2, ad3 As OleDb.OleDbDataAdapter
    Dim ds, ds1, ds2, ds3 As New Data.DataSet
    Dim cb, cb1 As OleDb.OleDbCommandBuilder
    Dim str, str1, str2, str3, conn As String
    Protected Sub btndelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btndelete.Click
        Dim venue As String
        Dim Rowno, SNo, Rownos, SNos, oldSNo, oldbkid, NewSNo, BkngID As Integer
        Dim todaydate = Date.Today
        venue = DropDownList1.SelectedItem.Text
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str3 = "select * from BookingDetails "
        ad3 = New OleDb.OleDbDataAdapter(str3, conn)
        ad3.Fill(ds3)

        str2 = "select * from NotifyDeletedRoom"
        ad2 = New OleDb.OleDbDataAdapter(str2, conn)
        ad2.Fill(ds2)
        cb = New OleDb.OleDbCommandBuilder(ad2)
        For i As Integer = 0 To ds3.Tables(0).Rows.Count - 1
            SNo = ds2.Tables(0).Rows.Count
            If SNo = 0 Then
                NewSNo = 1
            Else
                SNos = ds2.Tables(0).Rows.Count - 1
                oldSNo = ds2.Tables(0).Rows(SNos).Item(0)
                NewSNo = oldSNo + 1
            End If
            If venue = ds3.Tables(0).Rows(i).Item(2) And ds3.Tables(0).Rows(i).Item(5) >= todaydate Then
                Dim it As Data.DataRow
                it = ds2.Tables(0).NewRow
                it(0) = NewSNo
                it(1) = ds3.Tables(0).Rows(i).Item(0)
                it(2) = ds3.Tables(0).Rows(i).Item(1)
                it(3) = ds3.Tables(0).Rows(i).Item(2)
                it(4) = ds3.Tables(0).Rows(i).Item(3)
                it(5) = ds3.Tables(0).Rows(i).Item(4)
                it(6) = ds3.Tables(0).Rows(i).Item(5)
                ds2.Tables(0).Rows.Add(it)
            End If
        Next
        ad2.Update(ds2)
        
        str1 = "select * from DeletedRooms"
        ad1 = New OleDb.OleDbDataAdapter(str1, conn)
        ad1.Fill(ds1)
        cb = New OleDb.OleDbCommandBuilder(ad1)
        Rowno = ds1.Tables(0).Rows.Count
        If Rowno = 0 Then
            BkngID = 1
        Else
            Rownos = ds1.Tables(0).Rows.Count - 1
            oldbkid = ds1.Tables(0).Rows(Rownos).Item(0)
            BkngID = oldbkid + 1
        End If
        Dim items As Data.DataRow
        items = ds1.Tables(0).NewRow
        items(0) = BkngID
        items(1) = DropDownList1.SelectedItem.Text
        ds1.Tables(0).Rows.Add(items)
        ad1.Update(ds1)

        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from ResourceDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        cb = New OleDb.OleDbCommandBuilder(ad)
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If DropDownList1.SelectedItem.Text = ds.Tables(0).Rows(i).Item(0) Then
                ds.Tables(0).Rows(i).Delete()
            End If
        Next
        ad.Update(ds)
        MsgBox("Deleted Successfully")
        Response.Redirect("Frontpage.aspx")
    End Sub

    Protected Sub DropDownList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DropDownList1.SelectedIndexChanged
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from ResourceDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        cb = New OleDb.OleDbCommandBuilder(ad)
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If DropDownList1.SelectedItem.Text = ds.Tables(0).Rows(i).Item(0) Then
                Label2.Visible = True
                Label3.Visible = True
                Label4.Visible = True
                lblchair.Visible = True
                lblmic.Visible = True
                lblprojector.Visible = True
                btndelete.Visible = True
                lblchair.Text = ds.Tables(0).Rows(i).Item(1)
                lblmic.Text = ds.Tables(0).Rows(i).Item(2)
                lblprojector.Text = ds.Tables(0).Rows(i).Item(3)
            End If
        Next
    End Sub
End Class
