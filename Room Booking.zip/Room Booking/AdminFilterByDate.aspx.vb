﻿Imports System.Data

Partial Class FilterByDate
    Inherits System.Web.UI.Page
    Private MinDate As Date = Date.MinValue
    Private MaxDate As Date = Date.MaxValue
    Dim ad1 As OleDb.OleDbDataAdapter
    Dim ds1 As New Data.DataSet
    Dim cb1 As OleDb.OleDbCommandBuilder
    Dim str1, conn As String

    Protected Sub btncal_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btncal.Click
        Caldate.Visible = True
    End Sub

    
    Protected Sub Caldate_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles Caldate.DayRender
        If (e.Day.Date.DayOfWeek = DayOfWeek.Sunday) Then

            'e.Cell.ApplyStyle(new Style { BackColor = System.Drawing.Color.Gray })
            e.Day.IsSelectable = False
        End If
        If e.Day.Date <= MinDate OrElse e.Day.Date >= MaxDate Then
            e.Day.IsSelectable = False

        End If
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str1 = "select * from BookingDetails"

        ad1 = New OleDb.OleDbDataAdapter(str1, conn)
        ad1.Fill(ds1)
        cb1 = New OleDb.OleDbCommandBuilder(ad1)
        'If GridView1.Visible = False Then
        '    Lblnotavail.Visible = True
        'End If

        If ds1.Tables(0).Rows.Count = 0 Then
            Lblnotavail.Visible = True
            GridView1.Visible = False

        End If
    End Sub



    'Protected Sub btncal1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btncal1.Click
    '    caldate1.Visible = True
    'End Sub

    'Protected Sub Btnfetch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btnfetch.Click

    'End Sub

    'Protected Sub caldate1_DayRender(ByVal sender As Object, ByVal e As System.Web.UI.WebControls.DayRenderEventArgs) Handles caldate1.DayRender
    '    If (e.Day.Date.DayOfWeek = DayOfWeek.Sunday) Then

    '        'e.Cell.ApplyStyle(new Style { BackColor = System.Drawing.Color.Gray })
    '        e.Day.IsSelectable = False
    '    End If
    '    If e.Day.Date <= MinDate OrElse e.Day.Date >= MaxDate Then
    '        e.Day.IsSelectable = False

    '    End If
    'End Sub

    Protected Sub Caldate_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Caldate.SelectionChanged
        Textfromdate.Text = Caldate.SelectedDate
        Caldate.Visible = False
        'texttodate.Text = caldate1.SelectedDate
        'caldate1.Visible = False
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str1 = "select * from BookingDetails"

        ad1 = New OleDb.OleDbDataAdapter(str1, conn)
        ad1.Fill(ds1)
        cb1 = New OleDb.OleDbCommandBuilder(ad1)
        If ds1.Tables(0).Rows.Count = 0 Then
            Lblnotavail.Visible = True
            GridView1.Visible = False

        End If
        Dim dateval As String = Textfromdate.Text
        Try
            For i As Integer = 0 To ds1.Tables(0).Rows.Count - 1

                If dateval = ds1.Tables(0).Rows(i).Item(5) Then
                    GridView1.Visible = True
                    Lblnotavail.Visible = False
                    Exit For
                Else
                    Lblnotavail.Visible = True
                    GridView1.Visible = False
                End If

            Next

        Catch ex As Exception

        End Try
    End Sub
End Class
