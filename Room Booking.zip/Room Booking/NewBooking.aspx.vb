﻿Imports System.Data
Partial Class NewBooking
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ad1 As OleDb.OleDbDataAdapter
    Dim ad2 As OleDb.OleDbDataAdapter
    Dim ad3 As OleDb.OleDbDataAdapter
    Dim ad4 As OleDb.OleDbDataAdapter
    Dim ad5 As OleDb.OleDbDataAdapter
    Dim ad6 As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim ds1 As New Data.DataSet
    Dim ds2 As New Data.DataSet
    Dim ds3 As New Data.DataSet
    Dim ds4 As New Data.DataSet
    Dim ds5 As New Data.DataSet
    Dim ds6 As New Data.DataSet
    Dim cb, cb6 As OleDb.OleDbCommandBuilder
    Dim str1, str2, str, conn, str3, str4, str5 As String
    Dim BkngID, waitingID As Integer
    Dim projector As String = ""
    Dim Rowno, Rowno1, Rowno2, Rownos, oldbkid, oldwtid, var As Integer
    Dim SnLoginID, SnVenue, SnDate, SnStartTime, SnEndTime, OldBookingID As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SnLoginID = Session("LoginID").ToString
        tbxloginid.Text = SnLoginID
        SnVenue  = Session("Venue").ToString
        tbxvenue.Text = SnVenue
        SnDate = Session("Date").ToString
        tbxdate.Text = SnDate
        SnStartTime = Session("StartTime").ToString
        tbxstarttime.Text = SnStartTime
        SnEndTime = Session("EndTime").ToString
        tbxendtime.Text = SnEndTime
        OldBookingID = Session("BookingID").ToString
        tbxolgbookingid.Text = OldBookingID

        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from LoginDetails"
        ad = New OleDb.OleDbDataAdapter(Str, conn)
        ad.Fill(ds)
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If tbxloginid.Text = ds.Tables(0).Rows(i).Item(0) Then
                tbxdeptname.Text = ds.Tables(0).Rows(i).Item(2).ToString
            End If
        Next

        str1 = "select * from BookingDetails"
        ad1 = New OleDb.OleDbDataAdapter(str1, conn)
        ad1.Fill(ds1)
        Rowno = ds1.Tables(0).Rows.Count
        If Rowno = 0 Then
            BkngID = 1
        Else
            Rownos = ds1.Tables(0).Rows.Count - 1
            oldbkid = ds1.Tables(0).Rows(Rownos).Item(1)
            BkngID = oldbkid + 1
        End If
        tbxbookingid.Text = BkngID

    End Sub

    Protected Sub btnavail_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnavail.Click
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str1 = "select * from BookingDetails"
        ad2 = New OleDb.OleDbDataAdapter(str1, conn)
        ad2.Fill(ds2)

        Dim Venue As String = tbxvenue.Text
        Dim BookingDate As Date = tbxdate.Text
        Dim StrtTime As Double = tbxstarttime.Text
        Dim EdTime As Double = tbxendtime.Text

        Dim i As Integer
        If ds2.Tables(0).Rows.Count = 0 Then
            Labelavailable.Visible = True
            btnavail.Visible = False
            btnwaitinglist.Visible = False
            LabelMike.Visible = True
            tbxmike.Visible = True
            LabelChair.Visible = True
            tbxchair.Visible = True
            LabelProjector.Visible = True
            radioyes.Visible = True
            radiono.Visible = True
            btnconfirm.Visible = True
            str2 = "select * from ResourceDetails"
            ad3 = New OleDb.OleDbDataAdapter(str2, conn)
            ad3.Fill(ds3)
            For j As Integer = 0 To ds3.Tables(0).Rows.Count - 1
                If Venue = ds3.Tables(0).Rows(j).Item(0) Then
                    textchair.Text = ds3.Tables(0).Rows(j).Item(1)
                    textmike.Text = ds3.Tables(0).Rows(j).Item(2)
                    textprojector.Text = ds3.Tables(0).Rows(j).Item(3)
                    Lblchairmax.Text = ds3.Tables(0).Rows(j).Item(1)
                    Lblmikemax.Text = ds3.Tables(0).Rows(j).Item(2)
                End If
            Next
            Lblmikeavail.Visible = True
            Lblchairavail.Visible = True
            Lblmikemax.Visible = True
            Lblchairmax.Visible = True

        ElseIf ds2.Tables(0).Rows.Count > 0 Then
            For i = 0 To ds2.Tables(0).Rows.Count - 1
                If Venue = ds2.Tables(0).Rows(i).Item(2) And BookingDate = ds2.Tables(0).Rows(i).Item(5) And StrtTime <= ds2.Tables(0).Rows(i).Item(7) And EdTime <= ds2.Tables(0).Rows(i).Item(7) Then
                    btnavail.Visible = False
                    Labelnotavail.Visible = True
                    btnwaitinglist.Visible = True
                    Labelavailable.Visible = False
                    LabelMike.Visible = False
                    tbxmike.Visible = False
                    LabelChair.Visible = False
                    tbxchair.Visible = False
                    LabelProjector.Visible = False
                    radioyes.Visible = False
                    radiono.Visible = False
                    btnconfirm.Visible = False
                    Lblmikeavail.Visible = False
                    Lblchairavail.Visible = False
                    Lblmikemax.Visible = False
                    Lblchairmax.Visible = False
                    Exit For
                Else
                    btnavail.Visible = False
                    Labelavailable.Visible = True
                    LabelMike.Visible = True
                    tbxmike.Visible = True
                    LabelChair.Visible = True
                    tbxchair.Visible = True
                    LabelProjector.Visible = True
                    radioyes.Visible = True
                    radiono.Visible = True
                    btnconfirm.Visible = True
                    str2 = "select * from ResourceDetails"
                    ad3 = New OleDb.OleDbDataAdapter(str2, conn)
                    ad3.Fill(ds3)
                    For j As Integer = 0 To ds3.Tables(0).Rows.Count - 1
                        If Venue = ds3.Tables(0).Rows(j).Item(0) Then
                            textchair.Text = ds3.Tables(0).Rows(j).Item(1)
                            textmike.Text = ds3.Tables(0).Rows(j).Item(2)
                            textprojector.Text = ds3.Tables(0).Rows(j).Item(3)
                            Lblchairmax.Text = ds3.Tables(0).Rows(j).Item(1)
                            Lblmikemax.Text = ds3.Tables(0).Rows(j).Item(2)
                        End If
                    Next
                    Lblmikeavail.Visible = True
                    Lblchairavail.Visible = True
                    Lblmikemax.Visible = True
                    Lblchairmax.Visible = True
                End If

            Next

        End If

    End Sub

    Protected Sub btnbook_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnbook.Click
        If radiono.Checked = True Then
            projector = "No"
        ElseIf radioyes.Checked = True Then
            projector = "Yes"
        Else
            MsgBox("please choose an option")
        End If
    End Sub

    Protected Sub btnconfirm_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnconfirm.Click
        If tbxmike.Text <= textmike.Text And tbxchair.Text <= textchair.Text Then
            btnbook.Visible = True
            btnconfirm.Visible = False
        Else
            btnconfirm.Visible = True
        End If

        If radiono.Checked = True Then
            projector = "No"
            tbxchair.Enabled = False
            tbxmike.Enabled = False
        ElseIf radioyes.Checked = True Then
            projector = "Yes"
            tbxchair.Enabled = False
            tbxmike.Enabled = False
        Else
            MsgBox("please choose an option")
            btnconfirm.Visible = True
            btnbook.Visible = False

        End If
    End Sub
    Protected Sub OnConfirm(ByVal sender As Object, ByVal e As EventArgs) Handles btnbook.Click
        If radiono.Checked = True Then
            projector = "No"
        Else
            radioyes.Checked = True
            projector = "Yes"
        End If
        Dim confirmValue As String = Request.Form("confirm_value")

        If confirmValue = "Yes" Then

            conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
            Try
                str1 = "select * from BookingDetails"
                ad1 = New OleDb.OleDbDataAdapter(str1, conn)
                ad1.Fill(ds1)
                cb = New OleDb.OleDbCommandBuilder(ad1)
                Dim items As Data.DataRow
                items = ds1.Tables(0).NewRow
                items(0) = tbxloginid.Text
                items(1) = tbxbookingid.Text
                items(2) = tbxvenue.Text
                items(3) = tbxdeptname.Text
                items(4) = tbxdesc.Text
                items(5) = tbxdate.Text
                items(6) = tbxstarttime.Text
                items(7) = tbxendtime.Text
                items(8) = tbxchair.Text
                items(9) = tbxmike.Text
                items(10) = projector
                ds1.Tables(0).Rows.Add(items)
                ad1.Update(ds1)
                MsgBox("Booking Successful")
                
            Catch ex As Exception

            End Try

            str5 = "select * from CancelDetail"
            ad6 = New OleDb.OleDbDataAdapter(str5, conn)
            ad6.Fill(ds6)
            cb6 = New OleDb.OleDbCommandBuilder(ad6)
            For j As Integer = 0 To ds6.Tables(0).Rows.Count - 1
                If tbxolgbookingid.Text = ds6.Tables(0).Rows(j).Item(2) Then
                    ds6.Tables(0).Rows(j).Delete()
                    Exit For
                End If
            Next
            ad6.Update(ds6)
            If tbxdeptname.Text = "Adminstrator" Then
                Response.Redirect("Frontpage.aspx")
            Else
                Response.Redirect("UsersFrontPage.aspx")
            End If
        End If

    End Sub
    Protected Sub Onwaiting(ByVal sender As Object, ByVal e As EventArgs)

        Dim confirmValue As String = Request.Form("confirm_value")

        If confirmValue = "Yes" Then

            conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"

            str4 = "select * from BookingDetails"
            ad5 = New OleDb.OleDbDataAdapter(str4, conn)
            ad5.Fill(ds5)

            Dim Venue As String = tbxvenue.Text
            Dim BookingDate As Date = tbxdate.Text
            Dim StrtTime As Double = tbxstarttime.Text
            Dim EdTime As Double = tbxendtime.Text

            For i = 0 To ds5.Tables(0).Rows.Count - 1
                If Venue = ds5.Tables(0).Rows(i).Item(2) And BookingDate = ds5.Tables(0).Rows(i).Item(5) Then
                    var = ds5.Tables(0).Rows(i).Item(1)
                End If
            Next

            str3 = "select * from WaitingDetails"
            ad4 = New OleDb.OleDbDataAdapter(str3, conn)
            ad4.Fill(ds4)
            cb = New OleDb.OleDbCommandBuilder(ad4)
            Rowno1 = ds4.Tables(0).Rows.Count
            If Rowno1 = 0 Then
                waitingID = 1
            Else
                Rowno2 = ds4.Tables(0).Rows.Count - 1
                oldwtid = ds4.Tables(0).Rows(Rowno2).Item(1)
                waitingID = oldwtid + 1
            End If

            For j As Integer = 0 To ds4.Tables(0).Rows.Count - 1
                If var <> ds4.Tables(0).Rows(j).Item(3) Then
                    Dim items As Data.DataRow
                    items = ds4.Tables(0).NewRow
                    items(0) = waitingID
                    items(1) = 1
                    items(2) = SnLoginID
                    items(3) = var
                    items(4) = Venue
                    items(5) = BookingDate
                    items(6) = StrtTime
                    items(7) = EdTime
                    ds4.Tables(0).Rows.Add(items)
                    ad4.Update(ds4)
                    MsgBox("Succesfully entered into the waiting list")
                Else
                    MsgBox("Sorry,The waiting list is full")
                End If
            Next
        Else
            Response.Redirect("Booking1.aspx")
        End If
    End Sub

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        If tbxdeptname.Text = "Adminstrator" Then
            Response.Redirect("Frontpage.aspx")
        Else
            Response.Redirect("UsersFrontPage.aspx")
        End If
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub
End Class
