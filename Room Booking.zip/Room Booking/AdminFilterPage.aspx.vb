﻿Imports System.Data
Partial Class AdminFilterPage
    Inherits System.Web.UI.Page
    Dim ad1 As OleDb.OleDbDataAdapter
    Dim ds1 As New Data.DataSet
    Dim cb1 As OleDb.OleDbCommandBuilder
    Dim str1, conn As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str1 = "select * from BookingDetails"

        ad1 = New OleDb.OleDbDataAdapter(str1, conn)
        ad1.Fill(ds1)
        cb1 = New OleDb.OleDbCommandBuilder(ad1)
       

        If ds1.Tables(0).Rows.Count = 0 Then
            Lblnotavail.Visible = True
            GridView1.Visible = False

        End If
    End Sub



    Protected Sub DropDownList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DropDownList1.SelectedIndexChanged
        Dim Dept As String = DropDownList1.SelectedItem.Text
        Try
            For i As Integer = 0 To ds1.Tables(0).Rows.Count - 1
                If ds1.Tables(0).Rows(i).Item(3) = Dept Then
                    GridView1.Visible = True
                    Lblnotavail.Visible = False
                    Exit For
                Else
                    Lblnotavail.Visible = True
                    GridView1.Visible = False
                End If

            Next

        Catch ex As Exception

        End Try

        If ds1.Tables(0).Rows.Count = 0 Then
            Lblnotavail.Visible = True
            GridView1.Visible = False

        End If
    End Sub
End Class
