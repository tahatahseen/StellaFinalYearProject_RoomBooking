﻿Imports System.Data
Partial Class UsersDeleteBooking
    Inherits System.Web.UI.Page
    Dim ad, ad1, ad2, ad3 As OleDb.OleDbDataAdapter
    Dim ds, ds1, ds2, ds3 As New Data.DataSet
    Dim cb, cb1, cb2 As OleDb.OleDbCommandBuilder
    Dim str, str1, str2, str3, conn As String
    Dim SnLoginID As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        SnLoginID = Session("LoginID").ToString
        tbxloginid.Text = SnLoginID
        tbxtodaydate.Text = Date.Today
    End Sub
    Protected Sub OnConfirm(ByVal sender As Object, ByVal e As EventArgs) Handles btndelete.Click
        Dim i As Integer
        Dim confirmValue As String = Request.Form("confirm_value")
        Dim Rowno, BkngID, oldbkid, Rownos As Integer
        If confirmValue = "Yes" Then
            Dim flag As Integer
            conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
            str1 = "select * from BookingDetails"
            str2 = "select * from WaitingDetails"
            str3 = "select * from CancelDetail"
            ad1 = New OleDb.OleDbDataAdapter(str1, conn)
            ad2 = New OleDb.OleDbDataAdapter(str2, conn)
            ad3 = New OleDb.OleDbDataAdapter(str3, conn)
            ad1.Fill(ds1)
            ad2.Fill(ds2)
            ad3.Fill(ds3)
            cb = New OleDb.OleDbCommandBuilder(ad2)
            cb1 = New OleDb.OleDbCommandBuilder(ad3)
            cb2 = New OleDb.OleDbCommandBuilder(ad1)

            Rowno = ds3.Tables(0).Rows.Count
            If Rowno = 0 Then
                BkngID = 1
            Else
                Rownos = ds3.Tables(0).Rows.Count - 1
                oldbkid = ds3.Tables(0).Rows(Rownos).Item(0)
                BkngID = oldbkid + 1
            End If

            For i = 0 To ds2.Tables(0).Rows.Count - 1
                If dropdownbookingid.SelectedItem.Text = ds2.Tables(0).Rows(i).Item(3) Then

                    Dim items As Data.DataRow
                    items = ds3.Tables(0).NewRow
                    items(0) = BkngID
                    items(1) = ds2.Tables(0).Rows(i).Item(2)
                    items(2) = dropdownbookingid.SelectedItem.Text
                    items(3) = ds2.Tables(0).Rows(i).Item(4)
                    items(4) = ds2.Tables(0).Rows(i).Item(5)
                    items(5) = ds2.Tables(0).Rows(i).Item(6)
                    items(6) = ds2.Tables(0).Rows(i).Item(7)
                    ds3.Tables(0).Rows.Add(items)
                    'MsgBox(ds2.Tables(0).Rows(i).Item(4))
                    ds2.Tables(0).Rows(i).Delete()
                    Exit For
                Else
                    flag = 0

                End If
            Next
            ad2.Update(ds2)
            ad3.Update(ds3)
            If flag = 0 Then

                For i = 0 To ds1.Tables(0).Rows.Count - 1
                    If dropdownbookingid.SelectedItem.Text = ds1.Tables(0).Rows(i).Item(1) Then
                        ds1.Tables(0).Rows(i).Delete()
                        Exit For
                    End If
                Next
                ad1.Update(ds1)
            End If
        End If
        Response.Redirect("UsersFrontPage.aspx")
    End Sub

    Protected Sub Fetch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Fetch.Click
        lvenue.Visible = True
        LabelVenue.Visible = True
        ldeptname.Visible = True
        LabelDepartmentname.Visible = True
        lDate.Visible = True
        Labeldate.Visible = True
        lstrttime.Visible = True
        Labelstarttime.Visible = True
        lendtime.Visible = True
        Labelendtime.Visible = True
        btndelete.Visible = True
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from BookingDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If dropdownbookingid.SelectedItem.Text = ds.Tables(0).Rows(i).Item(1) Then
                LabelVenue.Text = ds.Tables(0).Rows(i).Item(2).ToString
                LabelDepartmentname.Text = ds.Tables(0).Rows(i).Item(3).ToString
                Labeldate.Text = ds.Tables(0).Rows(i).Item(5).ToString
                Labelstarttime.Text = ds.Tables(0).Rows(i).Item(6).ToString
                Labelendtime.Text = ds.Tables(0).Rows(i).Item(7).ToString
            End If
        Next
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub
End Class
