﻿Imports System.Data
Partial Class AddLogin
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String
    Protected Sub btnadduser_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadduser.Click
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from LoginDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        cb = New OleDb.OleDbCommandBuilder(ad)
        If tbxpwd.Text <> tbxcpwd.Text Then
            MsgBox("Sorry, The new password and confirm password field should be the same")
            tbxpwd.Text = ""
            tbxcpwd.Text = ""
        Else

            Dim items As Data.DataRow
            items = ds.Tables(0).NewRow
            items(0) = tbxloginid.Text
            items(1) = tbxpwd.Text
            items(2) = tbxdept.Text
            ds.Tables(0).Rows.Add(items)
            ad.Update(ds)
            MsgBox("Addded Successfully")
            Response.Redirect("Frontpage.aspx")
        End If
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub
End Class
