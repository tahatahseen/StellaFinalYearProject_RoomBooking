﻿Imports System.Data
Partial Class UserDeletedRoomsNotification
    Inherits System.Web.UI.Page
    Dim ad, ad1, ad2, ad3 As OleDb.OleDbDataAdapter
    Dim ds, ds1, ds2, ds3 As New Data.DataSet
    Dim cb, cb1, cb2 As OleDb.OleDbCommandBuilder
    Dim SnLoginID As String
    Dim str, str1, str2, str3, conn As String
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        lbldate.Text = Date.Today
        SnLoginID = Session("LoginID").ToString
        lblloginid.Text = SnLoginID
    End Sub

    Protected Sub btnbook_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnbook.Click
        Response.Redirect("Booking1.aspx")
    End Sub

    Protected Sub btnokay_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnokay.Click
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str3 = "select * from NotifyDeletedRoom"
        ad3 = New OleDb.OleDbDataAdapter(str3, conn)
        ad3.Fill(ds3)
        cb = New OleDb.OleDbCommandBuilder(ad3)
        For i As Integer = 0 To ds3.Tables(0).Rows.Count - 1
            If SnLoginID = ds3.Tables(0).Rows(i).Item(1) And lbldate.Text <= ds3.Tables(0).Rows(i).Item(6) Then
                ds3.Tables(0).Rows(i).Delete()
            End If
        Next
        ad3.Update(ds3)
        MsgBox("Deleted successfully")
        If lblloginid.Text = "admin" Then
            Response.Redirect("Frontpage.aspx")
        Else
            Response.Redirect("UsersFrontPage.aspx")
        End If
    End Sub

    Protected Sub LinkButton2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton2.Click
        If lblloginid.Text = "admin" Then
            Response.Redirect("Frontpage.aspx")
        Else
            Response.Redirect("UsersFrontPage.aspx")
        End If
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub
End Class
