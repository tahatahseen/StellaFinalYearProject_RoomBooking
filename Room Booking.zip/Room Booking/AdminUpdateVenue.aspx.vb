﻿Imports System.Data
Partial Class AdminUpdateVenue
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String
    Protected Sub btnupdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Dim projector As String = ""
        Dim available As String = ""
        Dim flag = 0
        If RadioButton2.Checked = True Then
            projector = "No"
            Label1.Visible = False
        ElseIf RadioButton1.Checked = True Then
            projector = "Yes"
            Label1.Visible = False
        Else
            Label1.Visible = True
            flag = 1
        End If
        If RadioButton4.Checked = True Then
            available = "No"
            Label2.Visible = False
        ElseIf RadioButton3.Checked = True Then
            available = "Yes"
            Label2.Visible = False
        Else
            Label2.Visible = True
            flag = 1
        End If
        If flag = 0 Then
            conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
            str = "select * from ResourceDetails"
            ad = New OleDb.OleDbDataAdapter(str, conn)
            ad.Fill(ds)
            cb = New OleDb.OleDbCommandBuilder(ad)
            For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
                If DropDownList1.SelectedItem.Text = ds.Tables(0).Rows(i).Item(0) Then
                    ds.Tables(0).Rows(i).Item(1) = textchairs.Text
                    ds.Tables(0).Rows(i).Item(2) = textmic.Text
                    ds.Tables(0).Rows(i).Item(3) = projector
                    ds.Tables(0).Rows(i).Item(4) = available
                End If
            Next
            ad.Update(ds)
            MsgBox("Updated")
            Response.Redirect("Frontpage.aspx")
        Else
            MsgBox("Please choose an option")
        End If
    End Sub

    Protected Sub DropDownList1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DropDownList1.SelectedIndexChanged
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from ResourceDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        cb = New OleDb.OleDbCommandBuilder(ad)
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If DropDownList1.SelectedItem.Text = ds.Tables(0).Rows(i).Item(0) Then
                textchairs.Text = ds.Tables(0).Rows(i).Item(1)
                textmic.Text = ds.Tables(0).Rows(i).Item(2)
            End If
        Next
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub
End Class
