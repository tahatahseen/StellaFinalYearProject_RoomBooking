﻿Imports System.Data
Partial Class AdminPasswordChange
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String
   


    Protected Sub btnupdatepwd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnupdatepwd.Click
        conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
        str = "select * from LoginDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        cb = New OleDb.OleDbCommandBuilder(ad)
        If tbxnewpwd.Text <> tbxconfirmpwd.Text Then
            MsgBox("Sorry, The new password and confirm password field should be the same")
            tbxconfirmpwd.Text = ""
            tbxnewpwd.Text = ""
        Else
            For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
                If DropDownList1.SelectedItem.Text = ds.Tables(0).Rows(i).Item(2) Then
                    ds.Tables(0).Rows(i).Item(1) = tbxnewpwd.Text
                End If
            Next
            ad.Update(ds)
            MsgBox("Updated")
            Response.Redirect("Frontpage.aspx")
        End If

    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub
End Class
