﻿Imports System.Data
Partial Class Venue
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String
    Protected Sub btnadd_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Dim projector As String = ""
        Dim available As String = ""
        Dim flag = 0
        If radiono.Checked = True Then
            projector = "No"
            Label1.Visible = False
        ElseIf radioyes.Checked = True Then
            projector = "Yes"
            Label1.Visible = False
        Else
            Label1.Visible = True
            flag = 1
        End If
        If radiono0.Checked = True Then
            available = "No"
            Label2.Visible = False
        ElseIf radioyes0.Checked = True Then
            available = "Yes"
            Label2.Visible = False
        Else
            Label2.Visible = True
            flag = 1
        End If
        If flag = 0 Then
            conn = "Provider=SQLOLEDB;Data Source=server2;database=12cs4027RoomBooking;uid=sa;pwd=stella"
            str = "select * from ResourceDetails"
            ad = New OleDb.OleDbDataAdapter(str, conn)
            ad.Fill(ds)
            cb = New OleDb.OleDbCommandBuilder(ad)
            Dim items As Data.DataRow
            items = ds.Tables(0).NewRow
            items(0) = tbxvenue.Text
            items(1) = tbxchairs.Text
            items(2) = tbxmikes.Text
            items(3) = projector
            items(4) = available
            ds.Tables(0).Rows.Add(items)
            ad.Update(ds)
            MsgBox("Added Successfully")
            Response.Redirect("Frontpage.aspx")
        Else
            MsgBox("Please choose an option")
        End If
    End Sub

    Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkButton1.Click
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1))
        Response.Cache.SetNoStore()
        Session.Clear()
    End Sub

   
End Class
