﻿Imports System.Data
Partial Class cancelorderpage
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String
    
    Protected Sub LnkbtnCpMenu_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkbtnCpMenu.Click
        Response.Redirect("optionpage.aspx")
    End Sub

    Protected Sub LnkbtnCpLogout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkbtnCpLogout.Click
        Session.Clear()
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Session("un").ToString() IsNot Nothing) Then
            TbxCpUid.Text = Session("un").ToString()
        End If
    End Sub

    

End Class
