﻿Imports System.Data
Partial Class updatepage
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String

    Protected Sub LnkbtnUpMenu_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkbtnUpMenu.Click
        Response.Redirect("optionpage.aspx")
    End Sub

    Protected Sub LnkbtnUpLogout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkbtnUpLogout.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Session("un").ToString() IsNot Nothing) Then
            TbxUpUid.Text = Session("un").ToString()
        End If
       
    End Sub

    Protected Sub BtnUpGetdet_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnUpGetdet.Click
        conn = "Provider=sqloledb;server=TAHATAHSEEN;database=12ucsb540;uid=sa;pwd=stella;"
        str = "select *from UserDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If TbxUpUid.Text = ds.Tables(0).Rows(i).Item(0) Then
                TbxUpPwd.Text = ds.Tables(0).Rows(i).Item(1).ToString
                TbxUpCpwd.Text = ds.Tables(0).Rows(i).Item(2).ToString
                TbxUpCtno.Text = ds.Tables(0).Rows(i).Item(3).ToString
                TbxUpEid.Text = ds.Tables(0).Rows(i).Item(4).ToString
              
            End If
        Next

    End Sub

    Protected Sub BtnUpUpdatedet_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnUpUpdatedet.Click
        conn = "Provider=sqloledb;server=TAHATAHSEEN;database=12ucsb540;uid=sa;pwd=stella;"
        str = "select *from UserDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        cb = New OleDb.OleDbCommandBuilder(ad)

        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If TbxUpUid.Text = ds.Tables(0).Rows(i).Item(0) Then
                ds.Tables(0).Rows(i).Item(0) = TbxUpUid.Text
                ds.Tables(0).Rows(i).Item(1) = TbxUpPwd.Text
                ds.Tables(0).Rows(i).Item(2) = TbxUpCpwd.Text
                ds.Tables(0).Rows(i).Item(3) = TbxUpCtno.Text
                ds.Tables(0).Rows(i).Item(4) = TbxUpEid.Text
              
            End If
        Next
        ad.Update(ds)
        MsgBox("Successfully Updated")
    End Sub
End Class
