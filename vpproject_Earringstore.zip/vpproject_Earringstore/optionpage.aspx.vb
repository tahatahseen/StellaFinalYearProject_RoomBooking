﻿
Partial Class optionpage
    Inherits System.Web.UI.Page
    Dim UserID As String
    Dim ci As Integer
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim un, pwd As String
        un = Session("un").ToString
        pwd = Session("pwd").ToString
        LblOpuid.Text &= un & " ! "
        'If (Application.Item("uid") IsNot Nothing) Then
        '    LblOpuid.Text &= Application.Item("uid").ToString() & " ! "
        'End If

        ' LblOpuid.Text &= UserID & " ! "
        
    End Sub

    Protected Sub Linkbtnplaceorder_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Linkbtnplaceorder.Click
        Response.Redirect("itemspage.aspx")
    End Sub

    Protected Sub LinkBtntrackorder_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Linkbtntrackorder.Click
        Response.Redirect("trackorderpage.aspx")
    End Sub

    Protected Sub LinkBtncancelorder_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Linkbtncancelorder.Click
        Response.Redirect("cancelorderpage.aspx")
    End Sub

    Protected Sub Linkbtnupdatedet_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Linkbtnupdatedet.Click
        Response.Redirect("updatepage.aspx")
    End Sub


    Protected Sub LnkbtnOpLogout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkbtnOpLogout.Click

        Session.Clear()
        Response.Redirect("Homepage.aspx")
    End Sub


End Class
