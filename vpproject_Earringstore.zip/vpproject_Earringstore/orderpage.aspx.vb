﻿Imports System.Data
Partial Class orderpage
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String

    Protected Sub Imgbtncalendar_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles Imgbtncalendar.Click
        Calendarprfdate.Visible = True
    End Sub

  
    Protected Sub Calendarprfdate_SelectionChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Calendarprfdate.SelectionChanged
        TbxOrdpgDeliverydate.Text = Calendarprfdate.SelectedDate()

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        conn = "Provider=sqloledb;server=TAHATAHSEEN;database=12ucsb540;uid=sa;pwd=stella;"
       
        RngvdtrOrdpgDeliverydate.MinimumValue = Date.Today()
        'If (Application.Item("uid") IsNot Nothing) Then
        '    TbxOrdpgUid.Text = Application.Item("uid").ToString()
        'End If
        If (Session("un").ToString() IsNot Nothing) Then
            TbxOrdpgUid.Text = Session("un").ToString()
        End If

        If (Session("totamt") IsNot Nothing) Then
            TbxOrdpgTotamt.Text = Session("totamt").ToString()
        End If
        If (Session("ordersummary") IsNot Nothing) Then
            TbxOrdpgOrderSummary.Text = Session("ordersummary").ToString()
        End If



    End Sub

    Protected Sub DrpOrdpgPayment_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DrpOrdpgPayment.SelectedIndexChanged
        If (DrpOrdpgPayment.SelectedItem.Text = "Debit Card") Then
            LblOrdpgCardno.Visible = True
            TbxOrdpgCard1.Visible = True
            TbxOrdpgCard2.Visible = True
            TbxOrdpgCard3.Visible = True
            TbxOrdpgCard4.Visible = True

            TbxOrdpgCard1.Text = " "
            TbxOrdpgCard2.Text = " "
            TbxOrdpgCard3.Text = " "
            TbxOrdpgCard4.Text = " "

            TbxOrdpgCard1.Enabled = True
            TbxOrdpgCard2.Enabled = True
            TbxOrdpgCard3.Enabled = True
            TbxOrdpgCard4.Enabled = True
        ElseIf (DrpOrdpgPayment.SelectedItem.Text = "Credit Card") Then
            LblOrdpgCardno.Visible = True
            TbxOrdpgCard1.Visible = True
            TbxOrdpgCard2.Visible = True
            TbxOrdpgCard3.Visible = True
            TbxOrdpgCard4.Visible = True

            TbxOrdpgCard1.Text = " "
            TbxOrdpgCard2.Text = " "
            TbxOrdpgCard3.Text = " "
            TbxOrdpgCard4.Text = " "

            TbxOrdpgCard1.Enabled = True
            TbxOrdpgCard2.Enabled = True
            TbxOrdpgCard3.Enabled = True
            TbxOrdpgCard4.Enabled = True
        Else
            LblOrdpgCardno.Visible = False
            TbxOrdpgCard1.Visible = False
            TbxOrdpgCard2.Visible = False
            TbxOrdpgCard3.Visible = False
            TbxOrdpgCard4.Visible = False


        End If

    End Sub

    Protected Sub BtnOrdpgDone_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnOrdpgDone.Click
        'Dim orderno As Integer = 1001;
        conn = "Provider=sqloledb;server=TAHATAHSEEN;database=12ucsb540;uid=sa;pwd=stella;"
        str = "select *from OrderDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        cb = New OleDb.OleDbCommandBuilder(ad)
        Dim item As Data.DataRow
        item = ds.Tables(0).NewRow
        'Dim Orderid, count1 As Integer
        'count1 = ds.Tables(0).Rows.Count
        'If count1 = 0 Then
        '    Orderid = 1001
        'Else
        '    Orderid = ds.Tables(0).Rows(count1 - 1).Item(0) + 1
        '    TbxOrdpgOrderNo.Text = Orderid

        'End If
        'TbxOrdpgOrderNo.Text = ds.Tables(0).Rows.Count + 1
        item(0) = TbxOrdpgOrderNo.Text
        item(1) = TbxOrdpgName.Text
        item(2) = TbxOrdpgUid.Text
        item(3) = DrplistOrdpgCity.SelectedItem.Text
        item(4) = TbxOrdpgDeliverydate.Text
        item(5) = TbxOrdpgOrderSummary.Text
        item(6) = TbxOrdpgTotamt.Text
        ds.Tables(0).Rows.Add(item)
        ad.Update(ds)
        MsgBox("Congrats " & TbxOrdpgName.Text & " ! Your order is sucessfully booked !")
        Response.Redirect("optionpage.aspx")

    End Sub

   
    Protected Sub LnkbtnOrdgpMenu_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkbtnOrdpgMenu.Click
        Response.Redirect("optionpage.aspx")
    End Sub

    Protected Sub LnkbtnOrdpgLogout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkbtnOrdpgLogout.Click
        Session.Clear()
        Response.Redirect("Homepage.aspx")
    End Sub
End Class
