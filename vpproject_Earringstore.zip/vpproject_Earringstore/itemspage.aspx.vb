﻿
Partial Class _Default
    Inherits System.Web.UI.Page
    Dim price1 As Integer = 0
    Dim price2 As Integer = 0
    Dim price3 As Integer = 0
    Dim price4 As Integer = 0
    Dim price5 As Integer = 0
    Dim price6 As Integer = 0
    Dim price7 As Integer = 0
    Dim price8 As Integer = 0
    Dim price9 As Integer = 0
    Dim price10 As Integer = 0
    Dim price11 As Integer = 0
    Dim price12 As Integer = 0
    Dim price13 As Integer = 0
    Dim price14 As Integer = 0
    Dim price15 As Integer = 0
    Dim price16 As Integer = 0
    Dim price17 As Integer = 0
    Dim price18 As Integer = 0
    Dim price19 As Integer = 0
    Dim price20 As Integer = 0
    Dim price21 As Integer = 0
    Dim price22 As Integer = 0
    Dim price23 As Integer = 0
    Dim price24 As Integer = 0
    Dim price25 As Integer = 0
    Dim prd1qty As Integer
    Dim prd2qty As Integer
    Dim prd3qty As Integer
    Dim prd4qty As Integer
    Dim prd5qty As Integer
    Dim prd6qty As Integer
    Dim prd7qty As Integer
    Dim prd8qty As Integer
    Dim prd9qty As Integer
    Dim prd10qty As Integer
    Dim prd11qty As Integer
    Dim prd12qty As Integer
    Dim prd13qty As Integer
    Dim prd14qty As Integer
    Dim prd15qty As Integer
    Dim prd16qty As Integer
    Dim prd17qty As Integer
    Dim prd18qty As Integer
    Dim prd19qty As Integer
    Dim prd20qty As Integer
    Dim prd21qty As Integer
    Dim prd22qty As Integer
    Dim prd23qty As Integer
    Dim prd24qty As Integer
    Dim prd25qty As Integer



   
    Protected Sub BtnIpShop_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnIpShop.Click
        If (chckbxpd1.Checked = True) Then
            price1 = CInt(Lblpdprice1.Text)
            prd1qty = CInt(Tbxqtyprd1.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid1.Text & " - " & "Product Price : " & price1 & " (Qty) - " & Tbxqtyprd1.Text
        End If

        If (chckbxpd2.Checked = True) Then
            price2 = CInt(Lblpdprice2.Text)
            prd2qty = CInt(Tbxqtyprd2.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid2.Text & " - " & "Product Price : " & price2 & " (Qty) - " & Tbxqtyprd2.Text
        End If

        If (chckbxpd3.Checked = True) Then
            price3 = CInt(Lblpdprice3.Text)
            prd3qty = CInt(Tbxqtyprd3.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid3.Text & " - " & "Product Price : " & price3 & " (Qty) - " & Tbxqtyprd3.Text
        End If

        If (chckbxpd4.Checked = True) Then
            price4 = CInt(Lblpdprice4.Text)
            prd4qty = CInt(Tbxqtyprd4.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid4.Text & " - " & "Product Price : " & price4 & " (Qty) - " & Tbxqtyprd4.Text
        End If

        If (chckbxpd5.Checked = True) Then
            price5 = CInt(Lblpdprice5.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid5.Text & " - " & "Product Price : " & price5 & " (Qty) - " & Tbxqtyprd5.Text
        End If

        If (chckbxpd6.Checked = True) Then
            price6 = CInt(Lblpdprice6.Text)
            prd6qty = CInt(Tbxqtyprd6.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid6.Text & " - " & "Product Price : " & price6 & " (Qty) - " & Tbxqtyprd6.Text
        End If

        If (chckbxpd7.Checked = True) Then
            price7 = CInt(Lblpdprice7.Text)
            prd7qty = CInt(Tbxqtyprd7.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid7.Text & " - " & "Product Price : " & price7 & " (Qty) - " & Tbxqtyprd7.Text
        End If

        If (chckbxpd8.Checked = True) Then
            price8 = CInt(Lblpdprice8.Text)
            prd8qty = CInt(Tbxqtyprd8.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid8.Text & " - " & "Product Price : " & price8 & " (Qty) - " & Tbxqtyprd8.Text
        End If

        If (chckbxpd9.Checked = True) Then
            price9 = CInt(Lblpdprice9.Text)
            prd9qty = CInt(Tbxqtyprd9.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid9.Text & " - " & "Product Price : " & price9 & " (Qty) - " & Tbxqtyprd9.Text
        End If

        If (chckbxpd10.Checked = True) Then
            price10 = CInt(Lblpdprice10.Text)
            prd10qty = CInt(Tbxqtyprd10.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid10.Text & " - " & "Product Price : " & price10 & " (Qty) - " & Tbxqtyprd10.Text
        End If

        If (chckbxpd11.Checked = True) Then
            price11 = CInt(Lblpdprice11.Text)
            prd11qty = CInt(Tbxqtyprd11.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid11.Text & " - " & "Product Price : " & price11 & " (Qty) - " & Tbxqtyprd11.Text
        End If

        If (chckbxpd12.Checked = True) Then
            price12 = CInt(Lblpdprice12.Text)
            prd12qty = CInt(Tbxqtyprd12.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid12.Text & " - " & "Product Price : " & price12 & " (Qty) - " & Tbxqtyprd12.Text
        End If

        If (chckbxpd13.Checked = True) Then
            price13 = CInt(Lblpdprice13.Text)
            prd13qty = CInt(Tbxqtyprd13.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid13.Text & " - " & "Product Price : " & price13 & " (Qty) - " & Tbxqtyprd13.Text
        End If

        If (chckbxpd14.Checked = True) Then
            price14 = CInt(Lblpdprice14.Text)
            prd14qty = CInt(Tbxqtyprd14.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid14.Text & " - " & "Product Price : " & price14 & " (Qty) - " & Tbxqtyprd14.Text
        End If

        If (chckbxpd15.Checked = True) Then
            price15 = CInt(Lblpdprice15.Text)
            prd15qty = CInt(Tbxqtyprd15.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid15.Text & " - " & "Product Price : " & price15 & " (Qty) - " & Tbxqtyprd15.Text
        End If

        If (chckbxpd16.Checked = True) Then
            price16 = CInt(Lblpdprice16.Text)
            prd16qty = CInt(Tbxqtyprd16.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid16.Text & " - " & "Product Price : " & price16 & " (Qty) - " & Tbxqtyprd16.Text
        End If

        If (chckbxpd17.Checked = True) Then
            price17 = CInt(Lblpdprice17.Text)
            prd17qty = CInt(Tbxqtyprd17.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid17.Text & " - " & "Product Price : " & price17 & " (Qty) - " & Tbxqtyprd17.Text
        End If

        If (chckbxpd18.Checked = True) Then
            price18 = CInt(Lblpdprice18.Text)
            prd18qty = CInt(Tbxqtyprd18.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid18.Text & " - " & "Product Price : " & price18 & " (Qty) - " & Tbxqtyprd18.Text
        End If

        If (chckbxpd19.Checked = True) Then
            price19 = CInt(Lblpdprice19.Text)
            prd19qty = CInt(Tbxqtyprd19.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid19.Text & " - " & "Product Price : " & price19 & " (Qty) - " & Tbxqtyprd19.Text
        End If

        If (chckbxpd20.Checked = True) Then
            price20 = CInt(Lblpdprice20.Text)
            prd20qty = CInt(Tbxqtyprd20.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid20.Text & " - " & "Product Price : " & price20 & " (Qty) - " & Tbxqtyprd20.Text
        End If

        If (chckbxpd21.Checked = True) Then
            price21 = CInt(Lblpdprice21.Text)
            prd21qty = CInt(Tbxqtyprd21.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid21.Text & " - " & "Product Price : " & price21 & " (Qty) - " & Tbxqtyprd21.Text
        End If

        If (chckbxpd22.Checked = True) Then
            price22 = CInt(Lblpdprice22.Text)
            prd22qty = CInt(Tbxqtyprd22.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid22.Text & " - " & "Product Price : " & price22 & " (Qty) - " & Tbxqtyprd22.Text
        End If

        If (chckbxpd23.Checked = True) Then
            price23 = CInt(Lblpdprice23.Text)
            prd23qty = CInt(Tbxqtyprd23.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid23.Text & " - " & "Product Price : " & price23 & " (Qty) - " & Tbxqtyprd23.Text
        End If

        If (chckbxpd24.Checked = True) Then
            price24 = CInt(Lblpdprice24.Text)
            prd24qty = CInt(Tbxqtyprd24.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid24.Text & " - " & "Product Price : " & price24 & " (Qty) - " & Tbxqtyprd24.Text
        End If

        If (chckbxpd25.Checked = True) Then
            price25 = CInt(Lblpdprice25.Text)
            prd25qty = CInt(Tbxqtyprd25.Text)
            TbxIpOrdersummary.Text &= Environment.NewLine & "Product ID : " & Lblprid25.Text & " - " & "Product Price : " & price25 & " (Qty) - " & Tbxqtyprd25.Text
        End If


        TbxIpTotal.Text = (prd1qty * price1) + (prd2qty * price2) + (prd3qty * price3) + (prd4qty * price4) + (prd5qty * price5) + (prd6qty * price6) + (prd7qty * price7) + (prd8qty * price8) + (prd9qty * price9) + (prd10qty * price10) + (prd11qty * price11) + (prd12qty * price12) + (prd13qty * price13) + (prd14qty * price14) + (prd15qty * price15) + (prd16qty * price16) + (prd17qty * price17) + (prd18qty * price18) + (prd19qty * price19) + (prd20qty * price20) + (prd21qty * price21) + (prd22qty * price22) + (prd23qty * price23) + (prd24qty * price24) + (prd25qty * price25)
    End Sub


   
   
    Protected Sub BtnIpProceed_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnIpProceed.Click
        Session("totamt") = TbxIpTotal.Text
        Session("ordersummary") = TbxIpOrdersummary.Text

        Response.Redirect("orderpage.aspx", True)
    End Sub

    Protected Sub LnkbtnIpMenu_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkbtnIpMenu.Click
        Response.Redirect("optionpage.aspx")
    End Sub

    Protected Sub LnkbtnIpLogout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkbtnIpLogout.Click
        Session.Clear()
        Response.Redirect("Homepage.aspx")
    End Sub

  
   
   
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub
End Class
