﻿
Partial Class _Default
    Inherits System.Web.UI.Page



    Protected Sub imgbtnpd1_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnpd1.Click
        MsgBox("Please login to place an order")
        Response.Redirect("loginpage.aspx")
    End Sub

    Protected Sub imgbtnpd2_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnpd2.Click
        MsgBox("Please login to place an order")
        Response.Redirect("loginpage.aspx")
    End Sub

    Protected Sub imgbtnpd3_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnpd3.Click
        MsgBox("Please login to place an order")
        Response.Redirect("loginpage.aspx")
    End Sub

    Protected Sub imgbtnpd4_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnpd4.Click
        MsgBox("Please login to place an order")
        Response.Redirect("loginpage.aspx")
    End Sub

    Protected Sub imgbtnpd9_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnpd9.Click
        MsgBox("Please login to place an order")
        Response.Redirect("loginpage.aspx")
    End Sub

    Protected Sub imgbtnpd7_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnpd7.Click
        MsgBox("Please login to place an order")
        Response.Redirect("loginpage.aspx")
    End Sub

    Protected Sub imgbtnpd6_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnpd6.Click
        MsgBox("Please login to place an order")
        Response.Redirect("loginpage.aspx")
    End Sub

    Protected Sub imgbtnpd5_Click(ByVal sender As Object, ByVal e As System.Web.UI.ImageClickEventArgs) Handles imgbtnpd5.Click

        MsgBox("Please login to place an order")
        Response.Redirect("loginpage.aspx")
    End Sub

    Protected Sub LinkBtnHpHome_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkBtnHpHome.Click

        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub LinkBtnHpLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkBtnHpLogin.Click

        Response.Redirect("loginpage.aspx")
    End Sub
End Class
