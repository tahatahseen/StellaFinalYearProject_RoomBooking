﻿Imports System.Data
Partial Class loginpage
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String
    
    

    Protected Sub LinkbtnLpSignup_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkbtnLpSignup.Click
        Response.Redirect("signuppage.aspx")
    End Sub

    Protected Sub BtnLpLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnLpLogin.Click
        conn = "Provider=sqloledb;server=TAHATAHSEEN;database=12ucsb540;uid=sa;pwd=stella;"
        Str = "select *from UserDetails"
        ad = New OleDb.OleDbDataAdapter(Str, conn)
        ad.Fill(ds)
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If TbxLpUid.Text = ds.Tables(0).Rows(i).Item(0) And TbxLpPwd.Text = ds.Tables(0).Rows(i).Item(1) Then
                'Application.Item("uid") = TbxLpUid.Text
                Session("un") = TbxLpUid.Text
                Session("pwd") = TbxLpPwd.Text
                Session("tm") = Date.Now()
                Server.Transfer("optionpage.aspx")


            End If

        Next
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If TbxLpUid.Text IsNot ds.Tables(0).Rows(i).Item(0) And TbxLpPwd.Text IsNot ds.Tables(0).Rows(i).Item(1) Then
                MsgBox("Sorry ! The UserName or the password you entered is incorrect.")
                Exit For
            End If
        Next

    End Sub

    Protected Sub LinkBtnLpHome_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkBtnLpHome.Click
        Response.Redirect("Homepage.aspx")
    End Sub

    
  
End Class
