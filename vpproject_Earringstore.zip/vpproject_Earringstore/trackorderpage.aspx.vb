﻿
Partial Class trackorderpage
    Inherits System.Web.UI.Page
    Protected Sub LnkbtnTopMenu_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkbtnTopMenu.Click
        Response.Redirect("optionpage.aspx")
    End Sub

    Protected Sub LnkbtnTopLogout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LnkbtnTopLogout.Click
        Session.Clear()
        Response.Redirect("Homepage.aspx")
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If (Session("un").ToString() IsNot Nothing) Then
            TbxTopUid.Text = Session("un").ToString()
        End If
    End Sub

    Protected Sub DrplstTopOrderno_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DrplstTopOrderno.SelectedIndexChanged
        LblTopOdrsucces.Visible = True
    End Sub
End Class
