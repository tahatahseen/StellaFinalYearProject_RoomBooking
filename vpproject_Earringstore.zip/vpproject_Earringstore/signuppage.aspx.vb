﻿Imports System.Data
<System.Runtime.InteropServices.ComVisible(False)> Partial Class signuppage
    Inherits System.Web.UI.Page
    Dim ad As OleDb.OleDbDataAdapter
    Dim ds As New Data.DataSet
    Dim cb As OleDb.OleDbCommandBuilder
    Dim str, conn As String

    Protected Sub BtnSpRegister_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles BtnSpRegister.Click
        conn = "Provider=sqloledb;server=TAHATAHSEEN;database=12ucsb540;uid=sa;pwd=stella;"
        str = "select *from UserDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        cb = New OleDb.OleDbCommandBuilder(ad)
        Dim item As Data.DataRow
        item = ds.Tables(0).NewRow
        item(0) = TbxSpUid.Text
        item(1) = TbxSpPwd.Text
        item(2) = TbxSpCpwd.Text
        item(3) = TbxSpCtno.Text
        item(4) = TbxSpEid.Text
        ds.Tables(0).Rows.Add(item)
        ad.Update(ds)
        MsgBox("Registration Sucessfull ! Please Login Via Login Page To Continue ")
        Response.Redirect("loginpage.aspx")

    End Sub

    Protected Sub LinkBtnSpHome_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles LinkBtnSpHome.Click
        Response.Redirect("Homepage.aspx")
    End Sub

   
    Protected Sub Btnchck_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Btnchck.Click
        conn = "Provider=sqloledb;server=TAHATAHSEEN;database=12ucsb540;uid=sa;pwd=stella;"
        str = "select *from UserDetails"
        ad = New OleDb.OleDbDataAdapter(str, conn)
        ad.Fill(ds)
        For i As Integer = 0 To ds.Tables(0).Rows.Count - 1
            If TbxSpUid.Text = ds.Tables(0).Rows(i).Item(0) Then
                MsgBox("UserName Already Exists")
            End If
        Next
    End Sub
End Class
